package hu.tricfit.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * TricFit: the training app is a single HTML page (assets/www/index.html) shown in a WebView.
 * Android's WebView has no Web Bluetooth, so the sensor link (scan, connect, notifications),
 * vibration and keep-screen-on are provided natively through the "TricFitNative" JavaScript bridge.
 */
public class MainActivity extends Activity {
    static final int BG = Color.parseColor("#060708");
    WebView web;
    FrameLayout rootView;
    static final int BG_LIGHT = Color.parseColor("#f2f4ef");
    BleBridge ble;
    boolean openFromNotification;

    /** A notification was tapped: show the account page, where the notifications are listed. */
    void showAccount() {
        web.evaluateJavascript("window.__gp&&window.__gp.go&&window.__gp.go('coach')", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getBooleanExtra("tricfit_notification", false) && web != null) showAccount();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);   // chrome://inspect from a computer
        }

        web = new WebView(this);
        web.setBackgroundColor(BG);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // routines, history, settings live in localStorage
        s.setTextZoom(100);                    // the layout is sized for 100%
        s.setMediaPlaybackRequiresUserGesture(false);

        openFromNotification = getIntent() != null && getIntent().getBooleanExtra("tricfit_notification", false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (openFromNotification) { openFromNotification = false; showAccount(); }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme) || "tel".equals(scheme)
                        || "mailto".equals(scheme) || "geo".equals(scheme)) {   // links open in the browser / dialer / mail / maps
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });

        ble = new BleBridge(this, web);
        web.addJavascriptInterface(ble, "TricFitNative");

        FrameLayout root = new FrameLayout(this);
        rootView = root;
        root.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupBars(root);

        web.loadUrl("file:///android_asset/www/index.html");   // all app state is kept in localStorage
    }

    /** Dark system bars; on Android 11+ draw edge-to-edge and pad the page by the bar (and keyboard) sizes. */
    @SuppressWarnings("deprecation")
    private void setupBars(View root) {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                return WindowInsets.CONSUMED;
            });
        } else {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        }
    }

    /** Light / dark theme from the page: background behind the system bars and light or dark bar icons. */
    @SuppressWarnings("deprecation")
    void applyTheme(boolean light) {
        runOnUiThread(() -> {
            int bg = light ? BG_LIGHT : BG;
            if (rootView != null) rootView.setBackgroundColor(bg);
            if (web != null) web.setBackgroundColor(bg);
            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int f = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light ? f : 0, f);
                }
            } else {
                getWindow().setStatusBarColor(bg);
                getWindow().setNavigationBarColor(bg);
                View d = getWindow().getDecorView();
                int ui = d.getSystemUiVisibility();
                ui = light ? (ui | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (ui & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                if (Build.VERSION.SDK_INT >= 26) ui = light ? (ui | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (ui & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                d.setSystemUiVisibility(ui);
            }
        });
    }

    /** Called from JavaScript (bridge thread). */
    void keepScreenOn(boolean on) {
        runOnUiThread(() -> {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // let the page close sheets / go back to the home tab first
        web.evaluateJavascript("(window.__gpBack&&window.__gpBack())?'1':'0'", v -> {
            if (v == null || !v.contains("1")) moveTaskToBack(true);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        ble.onPermissionsResult(requestCode, grantResults);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ble.onActivityResult(requestCode, resultCode);
    }

    @Override
    protected void onDestroy() {
        ble.shutdown();
        web.destroy();
        super.onDestroy();
    }
}
