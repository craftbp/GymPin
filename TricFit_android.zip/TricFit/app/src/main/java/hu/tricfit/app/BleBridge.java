package hu.tricfit.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;

/**
 * Native side of the TricFit sensor link, exposed to the page as window.TricFitNative.
 *
 * Page -> native : bleConnect(), bleDisconnect(), vibrate("[ms,ms,...]"), keepAwake(bool)
 * Native -> page : __gpBle.state(name[,code]), __gpBle.battery(percent), __gpBle.data("x,y,z,x,y,z,x,y,z")
 *
 * The sensor (Seeed XIAO nRF52840 Sense, firmware TricFitSensor.ino) advertises as "TricFit" and sends
 * 20-byte notifications at ~17 Hz: uint16 sequence + 3 samples x (x,y,z) int16 milli-g, little endian.
 */
@SuppressLint("MissingPermission")   // every Bluetooth call happens after hasPerms() succeeded
public class BleBridge {
    static final UUID SVC = UUID.fromString("7a1c0001-5e1a-4b8e-9c3d-1f2a6b0d4e01");
    static final UUID CHR = UUID.fromString("7a1c0002-5e1a-4b8e-9c3d-1f2a6b0d4e01");
    static final UUID BATT_SVC = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    static final UUID BATT_CHR = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    static final int REQ_PERM = 41, REQ_BT = 42;

    final MainActivity act;
    final WebView web;
    final Handler ui = new Handler(Looper.getMainLooper());
    final BluetoothAdapter adapter;
    BluetoothLeScanner scanner;
    volatile BluetoothGatt gatt;
    volatile int step = 0;            // 0 idle, 1 enabling data notifications, 2 ready, 3 battery read
    volatile boolean userClosed = false;
    boolean scanning = false;
    int lastSeq = -1;
    final LinkedHashMap<String, ScanResult> found = new LinkedHashMap<>();

    BleBridge(MainActivity a, WebView w) {
        act = a;
        web = w;
        BluetoothManager m = (BluetoothManager) a.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = m != null ? m.getAdapter() : null;
    }

    // ------------------------------------------------------------------ page -> native
    @JavascriptInterface
    public void bleConnect() { ui.post(this::start); }

    @JavascriptInterface
    public void bleDisconnect() {
        ui.post(() -> {
            userClosed = true;
            stopScan();
            BluetoothGatt g = gatt;
            if (g != null) g.disconnect();
            else jsState("off", null);
        });
    }

    @JavascriptInterface
    public void keepAwake(boolean on) { act.keepScreenOn(on); }

    // ---------- notifications (see NotifJob) ----------
    static final int REQ_NOTIF = 43;

    /** The page signed in (or refreshed its token): remember the session for the background check. */
    @JavascriptInterface
    public void setSession(String server, String token, String userId, String seen) {
        android.content.SharedPreferences sp = NotifJob.prefs(act);
        boolean newUser = !userId.equals(sp.getString("uid", ""));
        android.content.SharedPreferences.Editor ed = sp.edit()
                .putString("server", server).putString("token", token).putString("uid", userId)
                .putLong("refreshed", System.currentTimeMillis());
        if (newUser || sp.getString("seen", "").compareTo(seen) < 0) ed.putString("seen", seen);
        ed.apply();
        NotifJob.schedule(act);
    }

    @JavascriptInterface
    public void clearSession() {
        NotifJob.prefs(act).edit().clear().apply();
        NotifJob.cancel(act);
    }

    /** The page already showed notifications up to this "created" time: don't show them again. */
    @JavascriptInterface
    public void setSeen(String created) {
        android.content.SharedPreferences sp = NotifJob.prefs(act);
        if (created != null && sp.getString("seen", "").compareTo(created) < 0) sp.edit().putString("seen", created).apply();
    }

    /** Show an Android notification now (used while the app is in the background but still running). */
    @JavascriptInterface
    public void showNotification(String title, String body) {
        NotifJob.show(act, (int) (System.currentTimeMillis() & 0x7fffffff), title, body);
    }

    @JavascriptInterface
    public String notifState() {
        return NotifJob.allowed(act) ? "granted" : "denied";
    }

    @JavascriptInterface
    public void askNotifications() {
        act.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33
                    && act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    && act.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) | !NotifJob.prefs(act).getBoolean("asked", false)) {
                NotifJob.prefs(act).edit().putBoolean("asked", true).apply();
                act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            } else if (!NotifJob.allowed(act)) {
                try {     // turned off earlier: open the app's notification settings
                    act.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.getPackageName()));
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    @SuppressWarnings("deprecation")
    public void vibrate(String json) {
        try {
            JSONArray a = new JSONArray(json);
            if (a.length() == 0) return;
            Vibrator vib = Build.VERSION.SDK_INT >= 31
                    ? ((VibratorManager) act.getSystemService(Context.VIBRATOR_MANAGER_SERVICE)).getDefaultVibrator()
                    : (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
            if (vib == null || !vib.hasVibrator()) return;
            if (a.length() == 1) {
                vib.vibrate(VibrationEffect.createOneShot(Math.max(1, a.getLong(0)), VibrationEffect.DEFAULT_AMPLITUDE));
                return;
            }
            long[] t = new long[a.length() + 1];          // Android: [delay, on, off, on, ...]
            for (int i = 0; i < a.length(); i++) t[i + 1] = Math.max(0, a.getLong(i));
            vib.vibrate(VibrationEffect.createWaveform(t, -1));
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ permissions, Bluetooth on
    String[] perms() {
        return Build.VERSION.SDK_INT >= 31
                ? new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}
                : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }

    boolean hasPerms() {
        for (String p : perms()) if (act.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    void start() {
        if (adapter == null || !act.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            jsState("error", "noble");
            return;
        }
        if (scanning) return;
        if (gatt != null && step >= 2) { jsState("connected", null); return; }
        if (!hasPerms()) { act.requestPermissions(perms(), REQ_PERM); return; }
        ensureOn();
    }

    void onPermissionsResult(int code, int[] res) {
        if (code != REQ_PERM) return;
        boolean ok = res.length > 0;
        for (int r : res) ok &= r == PackageManager.PERMISSION_GRANTED;
        if (ok) { ensureOn(); return; }
        jsState("error", "perm");
        if (!act.shouldShowRequestPermissionRationale(perms()[0])) {     // "don't ask again": open the app settings
            try {
                act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.getPackageName())));
            } catch (Exception ignored) { }
        }
    }

    @SuppressWarnings("deprecation")
    void ensureOn() {
        if (!adapter.isEnabled()) {
            try { act.startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BT); }
            catch (Exception e) { jsState("error", "btoff"); }
            return;
        }
        if (Build.VERSION.SDK_INT < 31 && !locationOn()) { jsState("error", "loc"); return; }
        scan();
    }

    void onActivityResult(int code, int result) {
        if (code != REQ_BT) return;
        if (adapter != null && adapter.isEnabled()) ensureOn();
        else jsState("error", "btoff");
    }

    @SuppressWarnings("deprecation")
    boolean locationOn() {           // Android 6-11 return no scan results while Location is off
        LocationManager lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return true;
        if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
        try {
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) { return true; }
    }

    // ------------------------------------------------------------------ scanning
    final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) { consider(r); }
        @Override public void onBatchScanResults(List<ScanResult> rs) { for (ScanResult r : rs) consider(r); }
        @Override public void onScanFailed(int code) { scanning = false; ui.removeCallbacks(timeout); jsState("error", "scan"); }
    };
    final Runnable timeout = () -> { if (scanning) finishScan(); };
    final Runnable settle = () -> { if (scanning) finishScan(); };

    void consider(ScanResult r) {
        ScanRecord rec = r.getScanRecord();
        String name = rec != null ? rec.getDeviceName() : null;
        boolean svc = false;
        if (rec != null && rec.getServiceUuids() != null)
            for (ParcelUuid u : rec.getServiceUuids()) if (SVC.equals(u.getUuid())) svc = true;
        if (!svc && (name == null || !name.startsWith("TricFit"))) return;
        boolean first = found.isEmpty();
        found.put(r.getDevice().getAddress(), r);
        if (first) ui.postDelayed(settle, 1500);   // give a second sensor nearby a moment to show up
    }

    void scan() {
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { jsState("error", "btoff"); return; }
        found.clear();
        scanning = true;
        userClosed = false;
        jsState("scanning", null);
        ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try { scanner.startScan(null, st, scanCb); }
        catch (Exception e) { scanning = false; jsState("error", "scan"); return; }
        ui.postDelayed(timeout, 8000);
    }

    void stopScan() {
        if (scanning && scanner != null) {
            try { scanner.stopScan(scanCb); } catch (Exception ignored) { }
        }
        scanning = false;
        ui.removeCallbacks(timeout);
        ui.removeCallbacks(settle);
    }

    void finishScan() {
        if (!scanning) return;
        stopScan();
        if (found.isEmpty()) { jsState("error", "notfound"); return; }
        final List<ScanResult> list = new ArrayList<>(found.values());
        if (list.size() == 1) { connect(list.get(0).getDevice()); return; }
        list.sort((a, b) -> b.getRssi() - a.getRssi());     // nearest first
        String[] labels = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            ScanResult r = list.get(i);
            String n = r.getScanRecord() != null && r.getScanRecord().getDeviceName() != null ? r.getScanRecord().getDeviceName() : "TricFit";
            String a = r.getDevice().getAddress();
            labels[i] = n + "  ·  " + a.substring(Math.max(0, a.length() - 5)) + "  ·  " + r.getRssi() + " dBm";
        }
        new AlertDialog.Builder(act)
                .setTitle("TricFit")
                .setItems(labels, (d, i) -> connect(list.get(i).getDevice()))
                .setOnCancelListener(d -> jsState("off", null))
                .show();
    }

    // ------------------------------------------------------------------ connection
    void connect(BluetoothDevice d) {
        BluetoothGatt old = gatt;
        if (old != null) { try { old.close(); } catch (Exception ignored) { } }
        step = 0;
        lastSeq = -1;
        userClosed = false;
        jsState("connecting", null);
        gatt = d.connectGatt(act, false, cb, BluetoothDevice.TRANSPORT_LE);
    }

    final BluetoothGattCallback cb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
                ui.postDelayed(() -> { try { g.discoverServices(); } catch (Exception ignored) { } }, 300);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                boolean wasReady = step >= 2;
                try { g.close(); } catch (Exception ignored) { }
                if (gatt == g) gatt = null;
                step = 0;
                if (userClosed) jsState("off", null);
                else if (wasReady) jsState("lost", null);
                else jsState("error", "gatt");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(SVC);
            BluetoothGattCharacteristic c = s != null ? s.getCharacteristic(CHR) : null;
            if (c == null) {
                userClosed = true;                 // not our sensor: close quietly after the message
                jsState("error", "nosvc");
                g.disconnect();
                return;
            }
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCCD);
            step = 1;
            if (d == null || !writeDesc(g, d)) ready(g);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            if (step == 1) ready(g);
        }

        // Android 13+ delivers the value as an argument, older versions only in the characteristic.
        @Override
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) { onRead(g, c, value); }

        @Override
        @SuppressWarnings("deprecation")
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) { onRead(g, c, c.getValue()); }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) { onData(c, value); }

        @Override
        @SuppressWarnings("deprecation")
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { onData(c, c.getValue()); }
    };

    void ready(BluetoothGatt g) {
        step = 2;
        jsState("connected", null);
        BluetoothGattService bs = g.getService(BATT_SVC);
        BluetoothGattCharacteristic bc = bs != null ? bs.getCharacteristic(BATT_CHR) : null;
        if (bc != null && !g.readCharacteristic(bc)) enableBattNotify(g, bc);
    }

    void onRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] v) {
        if (!BATT_CHR.equals(c.getUuid()) || step != 2) return;   // once (both callbacks may fire)
        step = 3;
        if (v != null && v.length > 0) jsBattery(v[0] & 0xff);
        enableBattNotify(g, c);
    }

    void enableBattNotify(BluetoothGatt g, BluetoothGattCharacteristic c) {
        g.setCharacteristicNotification(c, true);
        BluetoothGattDescriptor d = c.getDescriptor(CCCD);
        if (d != null) writeDesc(g, d);
    }

    @SuppressWarnings("deprecation")
    boolean writeDesc(BluetoothGatt g, BluetoothGattDescriptor d) {
        byte[] v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
        if (Build.VERSION.SDK_INT >= 33) return g.writeDescriptor(d, v) == BluetoothStatusCodes.SUCCESS;
        d.setValue(v);
        return g.writeDescriptor(d);
    }

    void onData(BluetoothGattCharacteristic c, byte[] v) {
        if (v == null) return;
        UUID u = c.getUuid();
        if (BATT_CHR.equals(u)) { if (v.length > 0) jsBattery(v[0] & 0xff); return; }
        if (!CHR.equals(u) || v.length < 20) return;
        int seq = (v[0] & 0xff) | ((v[1] & 0xff) << 8);
        if (seq == lastSeq) return;                                // same packet through both callbacks
        lastSeq = seq;
        StringBuilder sb = new StringBuilder(64);
        for (int k = 0; k < 9; k++) {
            int o = 2 + 2 * k;
            short x = (short) ((v[o] & 0xff) | (v[o + 1] << 8));
            if (k > 0) sb.append(',');
            sb.append(x);
        }
        js("window.__gpBle&&__gpBle.data('" + sb + "')");
    }

    void shutdown() {
        stopScan();
        BluetoothGatt g = gatt;
        if (g != null) {
            userClosed = true;
            try { g.disconnect(); g.close(); } catch (Exception ignored) { }
            gatt = null;
        }
    }

    // ------------------------------------------------------------------ native -> page
    void js(String code) { web.post(() -> web.evaluateJavascript(code, null)); }

    void jsState(String state, String code) {
        js("window.__gpBle&&__gpBle.state('" + state + "'" + (code != null ? ",'" + code + "'" : "") + ")");
    }

    void jsBattery(int pct) { js("window.__gpBle&&__gpBle.battery(" + pct + ")"); }
}
