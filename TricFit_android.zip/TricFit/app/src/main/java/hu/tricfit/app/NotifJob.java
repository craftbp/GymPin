package hu.tricfit.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Background check for TricFit notifications, without Google services (no Firebase):
 * a periodic JobScheduler job (Android runs it about every 15 minutes, when there is network)
 * asks the TricFit server for unread notifications and shows them as Android notifications.
 * While the app is open, the page itself polls every 30 s and shows them instantly.
 *
 * The page hands over the session through the TricFitNative bridge (setSession / clearSession / setSeen).
 */
public class NotifJob extends JobService {
    static final int JOB_ID = 4711;
    static final String CHANNEL = "tricfit";
    static final String PREFS = "tricfit_notif";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void schedule(Context c) {
        JobScheduler js = c.getSystemService(JobScheduler.class);
        if (js == null) return;
        for (JobInfo j : js.getAllPendingJobs()) if (j.getId() == JOB_ID) return;   // already scheduled
        JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(c, NotifJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)                     // survives a reboot (RECEIVE_BOOT_COMPLETED)
                .build();
        try { js.schedule(info); } catch (Exception ignored) { }
    }

    static void cancel(Context c) {
        JobScheduler js = c.getSystemService(JobScheduler.class);
        if (js != null) js.cancel(JOB_ID);
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        final Context ctx = getApplicationContext();
        new Thread(() -> {
            try { check(ctx); } catch (Exception ignored) { }
            jobFinished(params, false);
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }

    /** Fetch unread notifications newer than the last one seen and show them. */
    static void check(Context c) throws Exception {
        SharedPreferences sp = prefs(c);
        String server = sp.getString("server", null), token = sp.getString("token", null);
        if (server == null || token == null) return;

        // keep the session alive (the server token is valid for 5 days): refresh it about once a day
        long now = System.currentTimeMillis();
        if (now - sp.getLong("refreshed", 0) > 20L * 3600 * 1000) {
            JSONObject r = http("POST", server + "/api/collections/users/auth-refresh", token);
            if (r != null && r.has("token")) {
                token = r.getString("token");
                sp.edit().putString("token", token).putLong("refreshed", now).apply();
            }
        }

        String seen = sp.getString("seen", "");
        String filter = "(read=false" + (seen.isEmpty() ? "" : " && created>'" + seen.replace("'", "") + "'") + ")";
        JSONObject r = http("GET", server + "/api/collections/notifications/records?perPage=20&sort=created&filter="
                + URLEncoder.encode(filter, "UTF-8"), token);
        if (r == null) return;
        JSONArray items = r.optJSONArray("items");
        if (items == null || items.length() == 0) return;
        String last = seen;
        for (int i = 0; i < items.length(); i++) {
            JSONObject n = items.getJSONObject(i);
            show(c, n.optString("id").hashCode(), n.optString("title", "TricFit"), n.optString("body", ""));
            last = n.optString("created", last);
        }
        sp.edit().putString("seen", last).apply();
    }

    static JSONObject http(String method, String url, String token) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod(method);
            con.setConnectTimeout(15000);
            con.setReadTimeout(15000);
            con.setRequestProperty("Authorization", token);
            con.setRequestProperty("Accept", "application/json");
            if ("POST".equals(method)) {
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = con.getOutputStream()) { os.write("{}".getBytes(StandardCharsets.UTF_8)); }
            }
            int code = con.getResponseCode();
            if (code < 200 || code >= 300) return null;
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new JSONObject(bo.toString("UTF-8"));
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (con != null) con.disconnect();
        }
    }

    static boolean allowed(Context c) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.areNotificationsEnabled();
    }

    static void show(Context c, int id, String title, String body) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !allowed(c)) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "TricFit", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("Foglalások, visszaigazolások, értékelések, jóváhagyások");
        nm.createNotificationChannel(ch);
        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("tricfit_notification", true);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_tricfit)
                .setColor(0xFFD4FF26)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(id, n);
    }
}
