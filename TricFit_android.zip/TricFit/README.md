# TricFit – Android app

The TricFit training app (`app/src/main/assets/www/index.html`) in a WebView, with a native
Bluetooth LE bridge (`BleBridge.java`) for the TricFit motion sensor, vibration and keep-screen-on.

Build: `./gradlew assembleDebug` (JDK 17+, Android SDK platform 35) → `app/build/outputs/apk/debug/app-debug.apk`.
On GitHub: put `TricFit_android.zip` (this folder zipped as `TricFit/…`) in the repository root next to
`.github/workflows/build-apk.yml`; the workflow builds the APK and attaches it to the run as `TricFit-apk`.

The APK is signed with `app/tricfit.keystore` so every build can be installed over the previous one
(the saved routines and history stay on the phone).
Font: Archivo (SIL Open Font License, `assets/www/fonts/OFL.txt`). Exercise data and photos: Free Exercise DB (public domain).
