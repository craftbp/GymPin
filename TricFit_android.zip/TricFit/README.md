# TricFit – Android app

The TricFit training app (`app/src/main/assets/www/index.html`) in a WebView, with a native
Bluetooth LE bridge (`BleBridge.java`) for the TricFit motion sensor, vibration and keep-screen-on.

Build: `./gradlew assembleRelease` (JDK 17+, Android SDK platform 35) → `app/build/outputs/apk/release/app-release.apk`.
On GitHub: put `TricFit_android.zip` (this folder zipped as `TricFit/…`) in the repository root next to
`.github/workflows/build-apk.yml`; the workflow builds the APK and attaches it to the run as `TricFit-apk`.

Release builds (`./gradlew assembleRelease`) are signed with the secret TricFit key, which is never
stored in the repository: the workflow reads it from the repository secrets TRICFIT_KEYSTORE_B64,
TRICFIT_KEYSTORE_PASSWORD and TRICFIT_KEY_ALIAS. Same key every time, so updates install over the
previous version and the saved routines and history stay on the phone. Without the secrets the build
falls back to the Android debug key (for local testing only).
Font: Archivo (SIL Open Font License, `assets/www/fonts/OFL.txt`). Exercise data and photos: Free Exercise DB (public domain).
