"""GymPin – offline Hungarian translation of the Free Exercise DB instructions.

Runs on GitHub Actions (translate-exercises.yml) or on your own computer:
    pip install torch --index-url https://download.pytorch.org/whl/cpu
    pip install transformers sentencepiece sacremoses
    git clone --depth 1 https://github.com/yuhonas/free-exercise-db.git
    python tools/translate_exercises.py

Output: exercises_text.js  (window.EX_TEXT = {id: {n: hu name, en: [...], hu: [...]}})
The app loads it next to index.html, so instructions work without internet.

- Machine translation: Helsinki-NLP/opus-mt-tc-big-en-hu (OPUS-MT, CC-BY 4.0), runs locally on the CPU.
- tools/hu_kezi.json: hand-made translations; these always win over the machine translation.
- javitasok.json (repo root, or tools/): your own word fixes ("wrong": "right"), applied after translation.
"""
import json, os, re, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("GP_ROOT", Path.cwd()))
SRC = Path(os.environ.get("GP_SRC", ROOT / "free-exercise-db" / "dist" / "exercises.json"))
OUT = Path(os.environ.get("GP_OUT", ROOT / "exercises_text.js"))
MODEL = os.environ.get("MT_MODEL", "Helsinki-NLP/opus-mt-tc-big-en-hu")
BATCH = int(os.environ.get("MT_BATCH", "24"))
BEAMS = int(os.environ.get("MT_BEAMS", "4"))


def load_json(p, default):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


# ---------- imperial units -> metric, before translation ----------
def _num(s):
    return float(s.replace(",", "."))


def _fmt(v):
    v = round(v * 2) / 2 if v < 10 else round(v)
    return (str(int(v)) if v == int(v) else str(v)).replace(".", ",")


def metric(t):
    def rng(m, f, unit):
        a = _fmt(_num(m.group(1)) * f)
        return f"{a}–{_fmt(_num(m.group(2)) * f)} {unit}" if m.group(2) else f"{a} {unit}"
    t = re.sub(r"(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?[\s-]*(?:inches|inch|in\.)", lambda m: rng(m, 2.54, "cm"), t)
    t = re.sub(r"(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?[\s-]*(?:feet|foot|ft\.?)\b", lambda m: rng(m, 0.3048, "m"), t)
    t = re.sub(r"(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?[\s-]*(?:yards|yard|yds?)\b", lambda m: rng(m, 0.9144, "m"), t)
    t = re.sub(r"(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?[\s-]*(?:lbs|lb|pounds)\b", lambda m: rng(m, 0.4536, "kg"), t)
    return t


SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"(])")


def sentences(step):
    step = re.sub(r"\s+", " ", step.replace("li>", "")).strip()
    return [s for s in SPLIT.split(metric(step)) if s]


# ---------- translator ----------
def make_translator():
    if os.environ.get("MT_FAKE"):          # for testing the pipeline without the model
        return lambda xs: [f"[HU] {x}" for x in xs]
    import torch
    from transformers import MarianMTModel, MarianTokenizer
    torch.set_num_threads(os.cpu_count() or 2)
    print(f"Loading {MODEL} …", flush=True)
    tok = MarianTokenizer.from_pretrained(MODEL)
    model = MarianMTModel.from_pretrained(MODEL).eval()

    def run(xs):
        with torch.inference_mode():
            enc = tok(xs, return_tensors="pt", padding=True, truncation=True, max_length=400)
            out = model.generate(**enc, num_beams=BEAMS, max_new_tokens=400)
        return tok.batch_decode(out, skip_special_tokens=True)
    return run


def main():
    if not SRC.exists():
        sys.exit(f"Missing {SRC}. Run: git clone --depth 1 https://github.com/yuhonas/free-exercise-db.git")
    data = json.loads(SRC.read_text(encoding="utf-8"))
    hand = load_json(HERE / "hu_kezi.json", {})
    fixes = load_json(ROOT / "javitasok.json", None) or load_json(HERE / "javitasok.json", {})   # repo root copy wins
    fixes = fixes.get("csere", {})
    cache_p = ROOT / "mt_cache.json"
    cache = load_json(cache_p, {})

    # collect every unique sentence (many steps repeat, e.g. "Repeat for the recommended amount of repetitions.")
    todo = set()
    for e in data:
        if e["id"] in hand:
            continue
        todo.add(e["name"])
        for st in e["instructions"]:
            todo.update(sentences(st))
    todo = sorted((s for s in todo if s not in cache), key=len)
    print(f"{len(data)} exercises, {len(hand)} hand-translated, {len(todo)} sentences to translate", flush=True)

    if todo:
        tr = make_translator()
        t0 = time.time()
        for i in range(0, len(todo), BATCH):
            chunk = todo[i:i + BATCH]
            for s, h in zip(chunk, tr(chunk)):
                cache[s] = h
            done = i + len(chunk)
            if done % (BATCH * 10) == 0 or done == len(todo):
                el = time.time() - t0
                print(f"  {done}/{len(todo)}  {el/60:.1f} min, ~{el/done*(len(todo)-done)/60:.0f} min left", flush=True)
                cache_p.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")

    def fix(s):
        for a, b in fixes.items():
            s = s.replace(a, b)
        return s

    out = {}
    for e in data:
        en = [re.sub(r"\s+", " ", x.replace("li>", "")).strip() for x in e["instructions"]]
        if e["id"] in hand:
            h = hand[e["id"]]
            hu, name = h["hu"], h["n"]
        else:
            hu = [fix(" ".join(cache.get(s, s) for s in sentences(st))) for st in e["instructions"]]
            name = fix(cache.get(e["name"], e["name"]))
        keep = [i for i, x in enumerate(en) if x]          # drop empty steps
        out[e["id"]] = {"n": name, "en": [en[i] for i in keep], "hu": [hu[i] for i in keep if i < len(hu)]}

    js = ("/* GymPin – exercise instructions (EN: Free Exercise DB, Unlicense; HU: OPUS-MT CC-BY 4.0 + hand edits) */\n"
          "window.EX_TEXT=" + json.dumps(out, ensure_ascii=False, separators=(",", ":")) + ";\n")
    OUT.write_text(js, encoding="utf-8")
    print(f"Wrote {OUT} ({len(js)//1024} KB)")


if __name__ == "__main__":
    main()
