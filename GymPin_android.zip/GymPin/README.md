# GymPin – Android app

The GymPin training app (`app/src/main/assets/www/index.html`) in a WebView, with a native
Bluetooth LE bridge (`BleBridge.java`) for the GymPin motion sensor, vibration and keep-screen-on.

Build: `./gradlew assembleDebug` (JDK 17+, Android SDK platform 35) → `app/build/outputs/apk/debug/app-debug.apk`.
On GitHub: put `GymPin_android.zip` (this folder zipped as `GymPin/…`) in the repository root next to
`.github/workflows/build-apk.yml`; the workflow builds the APK and attaches it to the run as `GymPin-apk`.

The APK is signed with `app/gympin.keystore` so every build can be installed over the previous one
(the saved routines and history stay on the phone).
Font: Archivo (SIL Open Font License, `assets/www/fonts/OFL.txt`). Exercise data and photos: Free Exercise DB (public domain).
